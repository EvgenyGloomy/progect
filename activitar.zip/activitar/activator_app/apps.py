from django.apps import AppConfig


class ActivatorAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'activator_app'
